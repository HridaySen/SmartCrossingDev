import time
import board
import neopixel

# Configuration
NUM_LEDS = 30
PIN = board.D18       # Must be wired to Physical Pin 12 (GPIO 18)
COLOR = (255, 180, 0) # Amber color

# Initialize the light strip
pixels = neopixel.NeoPixel(PIN, NUM_LEDS, auto_write=True)

print("Turning lights ON...")
pixels.fill(COLOR)

# Keep the script alive so the lights stay on
try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    print("\nTurning lights OFF and exiting.")
    pixels.fill((0, 0, 0))
