import cv2
from picamera2 import Picamera2

class CameraModule:
    def __init__(self):
        # Raspberry Pi camera stream URL
        self.PI_IP = "192.168.2.7"        
        self.webcam_capture = None
        self.raspberry_pi_capture = None

    def get_webcam_capture(self):
        if self.webcam_capture is None:
            self.webcam_capture = cv2.VideoCapture(0)

            if not self.webcam_capture.isOpened():
                print("Error: Cannot open webcam")
                exit()

        return self.webcam_capture

    def get_raspberry_pi_capture(self):
        if self.raspberry_pi_capture is None:
            stream_url = f"http://{self.PI_IP}:8080/video"
            self.raspberry_pi_capture = cv2.VideoCapture(stream_url)

            if not self.raspberry_pi_capture.isOpened():
                print(f"Error: Cannot open Raspberry Pi camera stream at {stream_url}")
                exit()

        return self.raspberry_pi_capture
        
class PiCameraCapture:
    def __init__(self, width=640, height=480, format="RGB888"):
        self.picam2 = Picamera2()
        self.config = self.picam2.create_video_configuration(
            main={"size": (width, height), "format": format}
        )
        self.picam2.configure(self.config)
        self.is_running = False

    def open(self):
        #Start the camera stream
        self.picam2.start()
        self.is_running = True
        return True

    def isOpened(self):
        #Check if camera is running
        return self.is_running

    def read(self):
        """
        Returns:
            ret (bool), frame (numpy array)
        """
        if not self.is_running:
            return False, None

        frame = self.picam2.capture_array()

        # Convert RGB -> BGR (OpenCV standard)
        frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)

        return True, frame

    def release(self):
        """Stop camera"""
        if self.is_running:
            self.picam2.stop()
            self.is_running = False
    
