
import os
import sys
# Look for imports starting from the project root.
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from light_controller import LightController
lc = LightController()

lc.set_mode("off")
