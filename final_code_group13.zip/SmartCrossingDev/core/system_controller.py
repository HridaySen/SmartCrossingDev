import cv2
from core.camera_module import CameraModule, PiCameraCapture
from core.yolo_detector import YOLODetector
from core.zone import ZoneLoader
from core.light_controller import LightController
import os

class SystemController:
    def __init__(self):
        # Initialize components
        self.camera_module = PiCameraCapture()
        self.camera_module.open()
        self.yolo_detector = YOLODetector()
        self.zones = ZoneLoader().zones
        self.light_controller = LightController()
    
    def start_system(self, camera_source="raspberry_pi"):
        # Get camera capture
        if camera_source == "webcam":
            cap = self.camera_module.get_webcam_capture()
        elif camera_source == "raspberry_pi":
            cap = self.camera_module

        while True:
            ret, frame = cap.read()
            zone_detection_occurred = False
            
            if not ret:
                print("Failed to grab frame")
                break

            results = self.yolo_detector.return_results(frame)
            persons = self.yolo_detector.get_person_bounding_boxes(frame, results)
            annotated_frame = self.yolo_detector.return_annotated_frame(frame, results)

            # Check for intersections with zones here
            for person in persons:
                for zone in self.zones:
                    if zone.check_intersection(person):
                        zone_detection_occurred = True
                        print(f"Person detected in zone {zone.zone_id}!")
                        # Write detection text on annotated frame
                        self.light_controller.set_mode("blink")
                        
                        cv2.putText(annotated_frame, f"Detected in Zone {zone.zone_id}", (int(person.x1), int(person.y1) - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
            
            if zone_detection_occurred == False:
                self.light_controller.set_mode("off")
            
            #cv2.imshow("Annotated Feed", annotated_frame)

            # Press 'q' to quit
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

        cap.release()
        cv2.destroyAllWindows()
    
    def stop_system(self):
        # Clean up resources if needed
        pass
