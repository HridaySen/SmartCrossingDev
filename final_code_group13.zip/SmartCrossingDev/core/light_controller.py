import time
import board
import neopixel
import threading

class LightController:
    def __init__(self, num_leds=30, pin=board.D18):
        self.num_leds = num_leds
        self.pixels = neopixel.NeoPixel(pin, num_leds, auto_write=False)

        # start the thread that will control the lights based on the current mode
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._running = True
        self._mode = "off"

        self._color = (255,45,0)

        self._thread.start()

    # this is the method the thread calls to control the lights based on the current mode
    def _run(self):
        while self._running:
            if self._mode == "blink":
                self.pixels.fill(self._color)
                self.pixels.show()
                time.sleep(0.5)

                self.pixels.fill((0, 0, 0))
                self.pixels.show()
                time.sleep(0.5)

            elif self._mode == "on":
                self.pixels.fill(self._color)
                self.pixels.show()
                time.sleep(0.1)

            elif self._mode == "off":
                self.pixels.fill((0, 0, 0))
                self.pixels.show()
                time.sleep(0.1)

    # public methods that will be used to control the lights from
    # the system controller
    def set_mode(self, mode):
        self._mode = mode

    def set_color(self, color):
        self._color = color

    def stop(self):
        self._running = False
